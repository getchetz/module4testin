package com.cg.runner;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(
		features={"C:\\Users\\chetannp\\Documents\\WorlSpaceE\\conference\\src\\test\\java\\com\\cg\\feature"}
		,glue= {"com.cg.stpdef"}
		,plugin = {"pretty", "html:target/chetan-report"}
		,monochrome=true
		,tags= {"@smoke"}		
		)
public class r
{    

}

 
