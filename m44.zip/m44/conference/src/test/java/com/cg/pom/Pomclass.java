package com.cg.pom;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Pomclass
{
	WebDriver driver;
	   @FindBy(how = How.XPATH,using="//*[@id=\"txtFirstName\"]") 
	   public static WebElement firstname;
	   
 
	   @FindBy(how = How.XPATH,using="//*[@id=\"txtLastName\"]") 
	   WebElement lastname;
	   
	   @FindBy(how = How.XPATH,using="//*[@id=\"txtEmail\"]") 
	   WebElement email;
	   
	   @FindBy(how = How.XPATH,using="//*[@id=\"txtPhone\"]") 
	   WebElement contact;
	   
	   @FindBy(how = How.NAME,using="size") 
	   WebElement numberattending;
	   
	   
	   @FindBy(how = How.XPATH,using="//*[@id=\"txtAddress1\"]") 
	   WebElement building;
	   
	   @FindBy(how = How.XPATH,using="//*[@id=\"txtAddress2\"]") 
	   WebElement area;
	   

	   
	   @FindBy(how = How.NAME,using="city") 
	   WebElement city;
	   
	   @FindBy(how = How.NAME,using="state") 
	   WebElement state;
	 
	   
	   @FindBy(how = How.LINK_TEXT,using="Next") 
	   public static WebElement next;
	   
	   
	   
	   
	   public Pomclass(WebDriver driver)
	   {
	       this.driver = driver;
	        PageFactory.initElements(driver, this);
	   }
	   
	   
	   @FindBy(how = How.XPATH,using="//*[@id=\"txtCardholderName\"]")
	   WebElement holdername;
	   
	   @FindBy(how = How.XPATH,using="//*[@id=\"txtDebit\"]")
	   WebElement cardnumber;
	   
	   @FindBy(how = How.XPATH,using="//*[@id=\"txtCvv\"]")
	   WebElement cvv;
	   
	   @FindBy(how = How.XPATH,using="//*[@id=\"txtMonth\"]")
	   WebElement month;
	   
	   @FindBy(how = How.XPATH,using="//*[@id=\"txtYear\"]")
	   WebElement year;
	   
	   @FindBy(how = How.XPATH,using="//*[@id=\"btnPayment\"]") 
	   public static WebElement makepayment;
	    
	     public void firstname(String n)
	     {
	    	 firstname.sendKeys(n);
	     }
	      
	    
	     
	     public void lastname(String n)
	     {
	    	 lastname.sendKeys(n);
	     }
	     
	     public void email1(String email1)
	     {
	         email.sendKeys(email1);
	     }
	     
	     public void contact(String contact1)
	     {
	    	 contact.sendKeys(contact1);
	     }     
	     
	     
	     public void number(String numberattending1)
	     {
	    	 Select s1=new Select(numberattending);
             s1.selectByValue("two");	    
         }  
	     
	   
	     public void building(String building1)
	     {
	    	 System.out.println(building1);
	    	 
	    	 building.sendKeys(building1);
	     } 
	     
	     public void area(String area1)
	     {
	    	 area.sendKeys(area1);
	     }
	      
	     public void city(String city1)
	     {
	    	 Select s3=new Select(city);
             s3.selectByValue("Bangalore");
 	     }  
	     
	     public void state(String state1)
	     {
	    	 Select s4=new Select(state);
             s4.selectByValue("Karnataka");
	    	 
 	     }
	     
	    
	     
	     public void radio(String name1)
	     {
	    	 List<WebElement> radio= driver.findElements(By.name("memberStatus"));
	    	 for(int i=0;i<radio.size();i++)
	    	 {
	    		 if(radio.get(i).getAttribute("value").equalsIgnoreCase(name1))
	    		 {
	    	    	 
	    	    	 
	    	    	 radio.get(i).click();	
	    	    	
	    	   	 }
	       	 }
	     }
	     
	     
	     public void next()
	     {
	    	 next.click();
	     }
	     
	     public void holder(String n)
	     {
	    	 holdername.sendKeys(n);
	     }
	     
	     public void card(String n)
	     {
	    	 cardnumber.sendKeys(n);
	     }
	     
	     public void cvv(String n)
	     {
	    	 cvv.sendKeys(n);
	     }
	     
	     public void mon(String n)
	     {
	    	 month.sendKeys(n);
	     }
	     
	     public void yer(String n)
	     {
	    	 year.sendKeys(n);
	     }
	     
	     public void makepay()
	     {
	    	 makepayment.click();;
	     }


	  
	   
	   
   
}

