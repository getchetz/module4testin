package com.cg.coaching.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class CoachingPage {

	WebDriver driver;
	
	@FindBy(how=How.NAME, using="fname")
	@CacheLookup
	private WebElement fname;

	@FindBy(how=How.NAME, using="lname")
	@CacheLookup
	private WebElement lname;
	
	@FindBy(how=How.NAME, using="email")
	@CacheLookup
	private WebElement email;
	
	@FindBy(how=How.NAME, using="mobile")
	@CacheLookup
	private WebElement mobile;
	
	@FindBy(how=How.NAME, using="tuitionType")
	@CacheLookup
	private WebElement tuitionType;
	
	@FindBy(how=How.NAME, using="learningMode")
	@CacheLookup
	private WebElement learningMode;
	
	@FindBy(how=How.NAME, using="city")
	@CacheLookup
	private WebElement city;
	
	@FindBy(how=How.NAME, using="enquiry")
	@CacheLookup
	private WebElement enquiry;

	@FindBy(how=How.NAME, using="request")
	@CacheLookup
	private WebElement request;
	
	@FindBy(how=How.NAME, using="reset")
	@CacheLookup
	private WebElement reset;
	
	@FindBy(how=How.NAME, using="text")
	@CacheLookup
	private WebElement text;
	
	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getFname() {
		return fname;
	}

	public WebElement getLname() {
		return lname;
	}

	public WebElement getEmail() {
		return email;
	}

	public WebElement getMobile() {
		return mobile;
	}

	public WebElement getTuitionType() {
		return tuitionType;
	}

	public WebElement getLearningMode() {
		return learningMode;
	}

	public WebElement getCity() {
		return city;
	}

	public WebElement getEnquiry() {
		return enquiry;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}

	public void setLname(String lname) {
		this.lname.sendKeys(lname);
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public void setTuitionType(String tuitionType) {
		//this.tuitionType.sendKeys(tuitionType);
		Select dropDown=new Select(this.tuitionType);
		dropDown.selectByVisibleText(tuitionType);
	}

	public void setLearningMode(String learningMode) {
		Select dropDown=new Select(this.learningMode);
		dropDown.selectByVisibleText(learningMode);
	}

	public void setCity(String city) {
		Select dropDown=new Select(this.city);
		dropDown.selectByVisibleText(city);
	}

	public void setEnquiry(String enquiry) {
		this.enquiry.sendKeys(enquiry);
	}

	public WebElement getRequest() {
		return request;
	}

	public WebElement getReset() {
		return reset;
	}

	public void setRequest() {
		this.request.click();
	}

	public void setReset() {
		this.reset.click();
	}

	public String getText() {
		return text.getText();
	}

	public void setText(WebElement text) {
		this.text = text;
	}
	
	
	
}
